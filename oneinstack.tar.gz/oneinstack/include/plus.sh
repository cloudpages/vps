#!/bin/bash

Install_Plus() {
    # set hostname
    if [ x"$sid" == x ]; then
        while :; do echo
        read  -p "Please input server name(Default: S1):  " sid
        if [ x"$sid" == x ]; then
            if [[ $sid = "" ]]; then 
                sid=S1
                break
            else 
                echo 
            fi 
        else
            break
        fi 
        done
    fi

    if [ x"$sid" == x ]; then
        echo $sid
    else  
        hostname $sid
        hostnamectl set-hostname $sid
    fi

    if [ ! -d "/www" ]; then
        mkdir /www
    fi
    if [ ! -d "/data" ]; then
        ln -s /www /data
    fi
    if [ ! -d "/www/vps" ]; then 
    # Genthe key
        if [ ! -f "/root/.ssh/id_rsa.pub" ]; then
        ssh-keygen -t rsa -C "$sid@server.tedx.net"
        fi
    # get access for git
        while :; do echo
        echo  -e "Open https://lyhiving.coding.net/p/vps/d/vps/git/settings/deploy-keys/new \nPlease upload the pubkey Below \n"
        cat /root/.ssh/id_rsa.pub
        echo  -e "\n"
        read -p "Please input any keys to continue" PUB_UPLOAD
        [ -z "$PUB_UPLOAD" ] && PUB_UPLOAD=
                mkdir -p /www/vps
                cd /www/vps
                git  clone git@e.coding.net:lyhiving/vps.git ./
            break
        done

    fi


    mkdir -p /root/__ORG__
    cd /root/__ORG__
    rm -rf /etc/rc.local.bak
    mv /etc/rc.local /etc/rc.local.bak
    ln -s /etc/rc.d/rc.local /etc/rc.local
    if [ ! -d "/etc/_auto_" ]; then
        ln -s /data/vps/_auto_ /etc/_auto_
        chmod a+x /etc/_auto_/*.sh
    fi
    if [ ! -d "/www/server/nginx/conf/diy" ]; then
        mkdir -p /www/server/nginx/conf/
        ln -s /data/vps/nginx/diy /www/server/nginx/conf/
    fi
    [ "${OS}" == "CentOS" ] && Cron_file=/var/spool/cron/root || Cron_file=/var/spool/cron/crontabs/root
    [ -z "`grep 'systemctl stop firewalld.service' /etc/rc.d/rc.local`" ] && echo "systemctl stop firewalld.service" >> /etc/rc.d/rc.local
    [ -z "`grep 'systemctl disable firewalld.service' /etc/rc.d/rc.local`" ] && echo "systemctl disable firewalld.service" >> /etc/rc.d/rc.local
    [ -z "`grep 'service iptables stop' /etc/rc.d/rc.local`" ] && echo "service iptables stop" >> /etc/rc.d/rc.local
    [ -z "`grep 'systemctl disable firewalld' /etc/rc.d/rc.local`" ] && echo "systemctl disable firewalld" >> /etc/rc.d/rc.local
    [ -z "`grep 'systemctl stop firewalld' /etc/rc.d/rc.local`" ] && echo "systemctl stop firewalld" >> /etc/rc.d/rc.local
    [ -z "`grep 'sh /etc/_auto_/status.sh' /etc/rc.d/rc.local`" ] && echo "sh /etc/_auto_/status.sh" >> /etc/rc.d/rc.local 
    [ -z "`grep 'hostname' /etc/rc.d/rc.local`" ] && echo "hostname $sid" >> /etc/rc.d/rc.local 
    [ -z "`grep 'hostnamectl' /etc/rc.d/rc.local`" ] && echo "hostnamectl set-hostname $sid" >> /etc/rc.d/rc.local  
    [ -z "`grep 'alias vps=' /etc/rc.d/rc.local`" ] && echo "alias vps='sh /etc/_auto_/git_vps.sh'" >> /root/.bashrc
    [ -z "`grep '/etc/_auto_/check502.sh' $Cron_file`" ] && echo "*/1 * * * * sh /etc/_auto_/check502.sh" >> $Cron_file
    [ -z "`grep '/etc/_auto_/git_vps.sh' $Cron_file`" ] && echo "*/2 * * * * sh /etc/_auto_/git_vps.sh" >> $Cron_file
    chmod +x /etc/rc.d/rc.local  
    chmod +x /etc/rc.local  
}

Uninstall_plus() {
    echo 
}